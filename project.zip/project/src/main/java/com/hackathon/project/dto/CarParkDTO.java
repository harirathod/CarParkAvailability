package com.hackathon.project.dto;


public class CarParkDTO {
    public String carParkName;
    public int totalSpace;
    public int availableSpaces;
}
